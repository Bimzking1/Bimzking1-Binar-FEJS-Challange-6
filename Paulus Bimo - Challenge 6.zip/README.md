# Cara Clone Project

1. git clone "https://github.com/Bimzking1/Binar-FEJS-Challange-6"
2. masuk ke directory project
3. npm install
4. npm start