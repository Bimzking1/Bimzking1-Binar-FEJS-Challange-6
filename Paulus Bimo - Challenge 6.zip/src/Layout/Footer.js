import React from 'react'

const Footer = () => {
  return (
    <div className="bg-gray-100">
        <div className='container text-xs py-2'>
            FEJS 2 | Mini Shop
        </div>
    </div>
  )
}

export default Footer